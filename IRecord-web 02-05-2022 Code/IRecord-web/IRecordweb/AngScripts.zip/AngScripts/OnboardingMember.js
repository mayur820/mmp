﻿var app = angular.module("myApp", []);
app.controller("myctrn", function ($scope, $http) {

    $scope.PageLoad = function () {
  //  alert("hii");
       $scope.getBroker();
	    $scope.getDemate();
		 $scope.getBank();
		  $scope.getConsultant();
		 $scope.demat_with_broker = [];
		  $scope.Single_demats = [];
		    $scope.Single_Bank = [];
					    $scope.Single_Advisor = [];
		  
		 $scope.details = [];
    }
 $scope.getBroker=function()
 {
  fnGetDataUsingGetRequestWithModel("/MemberMaster/GetBroker", "Info_Broker", $scope, $http);
 }
  $scope.getDemate=function()
 {
  fnGetDataUsingGetRequestWithModel("/MemberMaster/GetDemate", "Info_Demate", $scope, $http);
 }
  $scope.getBank=function()
 {
  fnGetDataUsingGetRequestWithModel("/MemberMaster/GetBank", "Info_Bank", $scope, $http);
 }
  $scope.getConsultant=function()
 {
  fnGetDataUsingGetRequestWithModel("/MemberMaster/GetConsultant", "Info_Consultant", $scope, $http);
 }
    $scope.FN_demat_with_broker = function () {
    
       if ($("#selectbrokerpopup").val() != ""  && $("#selectDematpopup").val() != "") {
          

		   var VIEWMODEL = {};
			   VIEWMODEL.DemateId = $("#selectDematpopup").val();
            VIEWMODEL.DemateName = fnGetddlText("selectDematpopup");
            VIEWMODEL.brokerId = $("#selectbrokerpopup").val();
            VIEWMODEL.BrokerName = fnGetddlText("selectbrokerpopup");
             $scope.demat_with_broker.push(VIEWMODEL);
            $("#selectbrokerpopup").val("");
			$("#selectDematpopup").val("");
      }
      else {
           alert("Plase Select Broker and Demate..");
           $("#selectbrokerpopup").focus();

	  }
     
    }
  $scope.FN_demat = function () {
    
   if ($("#ddl_Single_demat").val() != "" ) {
            var VIEWMODEL = {};
			   VIEWMODEL.DemateId = $("#ddl_Single_demat").val();
            VIEWMODEL.DemateName = fnGetddlText("ddl_Single_demat");
            
             $scope.Single_demats.push(VIEWMODEL);
            $("#ddl_Single_demat").val("");
			
     }
     else {
           alert("Plase Select Broker..");
      $("#ddl_Single_demat").focus();
	  return false;

   }
     
    }
  $scope.FN_Bank = function () {
    
       if ($("#ddlbankPopup").val() != "" ) {
            var VIEWMODEL = {};
			   VIEWMODEL.BankId = $("#ddlbankPopup").val();
            VIEWMODEL.BankName = fnGetddlText("ddlbankPopup");
            
             $scope.Single_Bank.push(VIEWMODEL);
            $("#ddlbankPopup").val("");
			
       }
       else {
            alert("Plase Select Bank..");
            $("#ddlbankPopup").focus();

        }
     
    }
	  $scope.Advisor = function () {
    
        if ($("#ddl_Advisor").val() != "" ) {
            var VIEWMODEL = {};
			   VIEWMODEL.AdvisorId = $("#ddl_Advisor").val();
            VIEWMODEL.AdvisorName = fnGetddlText("ddl_Advisor");
            
             $scope.Single_Advisor.push(VIEWMODEL);
            $("#ddl_Advisor").val("");
			
       }
       else {
           alert("Plase Select Advisor..");
           $("#ddl_Advisor").focus();

	   }
     
    }
	
  
    $scope.fnSubmit = function (data) {
	
		
		   var DefaultValues = {};
		   DefaultValues.BrokerWithDemate=$("#ddl_DefaultBroker").val();
		   		   DefaultValues.Demate=$("#ddl_DefaultDemat").val();
				      DefaultValues.BankAc=$("#ddl_DefaultBank").val();
					        DefaultValues.Advisor=$("#ddl_DefaultAdvisor").val();
		  var ListOfBrokerWithDemate = JSON.stringify($scope.demat_with_broker);
		    var ListOfDemate = JSON.stringify($scope.Single_demats);
			   var ListOfBankAc = JSON.stringify($scope.Single_Bank);
			     var ListOfAdvisor = JSON.stringify($scope.Single_Advisor);
				     var JsonDefaultValues = JSON.stringify(DefaultValues);
     
	  
	      var posturl = "/MemberMaster/SetMultiConfiguration"; 
        $http({
            method: "post",
            url: posturl,
            data: { 'JsonDefaultValues':'['+ JsonDefaultValues +']', 'ListOfBrokerWithDemate': ListOfBrokerWithDemate, 'ListOfDemate': ListOfDemate, 'ListOfBankAc': ListOfBankAc, 'ListOfAdvisor': ListOfAdvisor}
        }).then(function (response) {
			document.getElementById("signupform").submit();

       
			//  window.location.href="/Dashboard/Index";
            // $scope.GetAllMember();
        }, function (data) {
            alert("Error Occur During This Request" + posturl);
        });
	   
	   
   }
   
});

