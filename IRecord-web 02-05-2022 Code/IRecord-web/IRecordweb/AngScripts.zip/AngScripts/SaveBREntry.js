﻿var app = angular.module("myApp", ["ngStorage"]);
app.controller("myctrn", function ($scope, $http, $localStorage, $sessionStorage, $window) {
   // $scope.BILLS = null;
    $scope.PageLoad = function () {
      //  $scope.bindbills();
        $scope.GetAllDemate();
        $scope.GetAllConsultant();
        $scope.GetAllBroker();
        
        //$sessionStorage.SessionMessage = "hii";
        //alert(""+$sessionStorage.SessionMessage)
   

    }

   
    $scope.btnupload = function () {
        
        let photo = document.getElementById("contractnotefile").files[0];
        if (typeof photo !== 'undefined') {


            let formData = new FormData();

            formData.append("photo", photo);
            fetch('/BrokerBillEntry/Upload', { method: "POST", body: formData }).then(function () {

                alert("File Upload successfully");
            });
            $scope.btnupload = false;
        }
        else {
           // $("#ContractNoteId1").val("912");
           // $scope.ContractNoteId = "912";
           // alert($scope.SaveBREntry.ContractNoteId);
            alert("Please Select A files");
        }

    };
    
    $scope.bindbills = function () {


        //$http({
        //    method: "get",
        //    url: "/BrokerBillEntry/GetAllBILLS"
        //}).then(function (response) {
        //    $scope.BILLS = JSON.parse(response.data);
         
        //   // $scope.ContractNoteId = "912";
        //}, function (data) {
        //    //deferred.reject({ message: "Really bad" });
        //    alert("Error Occur During This Request" + geturl);
        //}).then(function() {
        //    //$("#ContractNoteId1").val("912");
           
        //})
       
         fnGetDataUsingGetRequestWithModel("/BrokerBillEntry/GetAllBILLS?Invtype=" + $("#ddlInvestmentType").val() + "&&Date=" + $("#txt_Date").val() + "&&BrokerID=" + $("#ddlBroker").val(), "BILLS", $scope, $http);
    }
    $scope.GetAllConsultant = function () {
        fnGetDataUsingGetRequestWithModel("/BrokerBillEntry/GetAllConsultant", "Consultants", $scope, $http);

    }
    $scope.GetAllDemate = function () {
        fnGetDataUsingGetRequestWithModel("/BrokerBillEntry/GetAllDemate", "Demates", $scope, $http);
        console.log($scope.Demates)
    }
    $scope.GetAllBroker = function () {
        fnGetDataUsingGetRequestWithModel("/BrokerBillEntry/GetAllBroker", "Brokers", $scope, $http);

    }
    
    $scope.btn_click_sumit = function () {
        debugger;

       // public string member_code { get; set; }
       // public string year_code { get; set; }
      
       //// public string Brokercode { get; set; }
       // public string invstyp { get; set; }
       // public string  { get; set; }
       // public string  { get; set; }
       // public string  { get; set; }
       // public string HoldingTypeCode { get; set; }
       // public string HoldingType { get; set; }

        var text = fnGetddlText("ContractNoteId")
        $scope.SaveBREntry.ContractNoteName = text;
        $scope.SaveBREntry.ContractNoteId = $scope.ContractNoteId;
        text = fnGetddlText("Demat_Ac_Id")
        $scope.SaveBREntry.Demat_Ac_Name = text;
        $scope.SaveBREntry.invstyp = $scope.ddlInvestmentType;

        $scope.SaveBREntry.Broker_Id = $scope.ddlBroker;
        $scope.SaveBREntry.Broker_Name = fnGetddlText("ddlBroker");
        ////
        $sessionStorage.TypeOfInvst = $scope.ddlInvestmentType;
        ////
        $scope.SaveBREntry.invstyptext =fnGetddlText("ddlInvestmentType");
        $scope.SaveBREntry.ConsultantCode = $scope.ddlConsultant;
        $scope.SaveBREntry.Consultant =fnGetddlText("ddlConsultant");
        $scope.SaveBREntry.HoldingTypeCode = $("#ddlHoldingType").val();
        $scope.SaveBREntry.HoldingType =fnGetddlText("ddlHoldingType");
        fnPostDataUsingPostRequestWithModel("/BrokerBillEntry/SaveBREntry", "SaveBREntry", $scope, $http);
        window.location.href = "/BrokerBillEntry/BRDetails";
    }
    //$scope.bindstate = function () {
    //    fnGetDataUsingGetRequestWithModel("/Home/GetAllState", "liststates", $scope, $http);
    //};
    //$scope.bindcity = function (id) {
    //    fnGetDataUsingGetRequestWithModel("/Home/GetCityByid?id=" + id, "listCitys", $scope, $http);
    //};
    //$scope.GetValue = function () {
    //    $scope.bindcity($scope.EmpModel.Stateid);
    //}
    //$scope.Getcitytext = function () {
    //    var text = fnGetddlText("ddl_City")
    //    $scope.EmpModel.Address = text;
    //}
    //$scope.GetEmps = function () {
    //    fnGetDataUsingGetRequestWithModel("/Home/GetAllEmp", "listemps", $scope, $http);
    //};
    //$scope.fnclare = function () {
    //    $scope.EmpModel.Stateid = "";
    //    $scope.EmpModel.CityId = "";
    //    $scope.EmpModel.Name = "";
    //    $scope.EmpModel.Address = "";
    //}

});

